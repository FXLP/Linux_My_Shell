/*
 * =====================================================================================
 *       Filename:  test.c
 *    Description:  
 *        Version:  1.0
 *        Created:  2013.10.16 20h40m39s
 *         Author:  wuyue (wy), vvuyve@gmail.com
 *        Company:  UESTC
 * =====================================================================================
 */
#include <stdio.h>
int main()
{
    printf("Hello world!\n");
    return 0;
}
